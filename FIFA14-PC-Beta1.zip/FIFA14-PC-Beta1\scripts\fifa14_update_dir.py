#!/usr/bin/env python3
"""fifa14: build the run folder of the game with an update applied, with hard links.

    python fifa14_update_dir.py "E:/games ps4/CUSA00111-port" "E:/games ps4/CUSA00111-patch0" \
        "E:/games ps4/CUSA00111-port-update"

<out> = every file of the base run folder (fifa14_game_dir.py), with the files of the update
folder placed over them at the same relative path (a file that exists only in sce_module/ of the
base, such as libc.prx, goes there). The update's files must be decrypted (ELF, not SELF). The
base folder and the update folder are not modified; the update stays optional.
"""
import os
import shutil
import sys
from pathlib import Path

SELF_MAGIC = b'O\x15=\x1d'


def place(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        dst.unlink()
    try:
        os.link(src, dst)
    except OSError:
        shutil.copy2(src, dst)  # another drive, or no hard-link support


def main(base, update, out):
    base, update, out = Path(base), Path(update), Path(out)
    by_name = {}
    linked = 0
    for p in base.rglob('*'):
        if p.is_file():
            rel = p.relative_to(base)
            place(p, out / rel)
            by_name.setdefault(p.name.lower(), []).append(rel)
            linked += 1
    replaced, added, refused = [], [], []
    for p in update.rglob('*'):
        if not p.is_file():
            continue
        with open(p, 'rb') as f:
            if f.read(4) == SELF_MAGIC:
                refused.append(str(p.relative_to(update)))
                continue
        rel = p.relative_to(update)
        if not (base / rel).exists() and len(by_name.get(p.name.lower(), [])) == 1:
            rel = by_name[p.name.lower()][0]  # libc.prx -> sce_module/libc.prx
        (replaced if (base / rel).exists() else added).append(str(rel))
        place(p, out / rel)
    print(f'{out}: {linked} base files linked, {len(replaced)} replaced, {len(added)} added')
    for r in refused:
        print(f'  ENCRYPTED (left out, base file kept)  {r}')
    return 1 if refused else 0


if __name__ == '__main__':
    if len(sys.argv) != 4:
        sys.exit(__doc__)
    sys.exit(main(*sys.argv[1:]))
