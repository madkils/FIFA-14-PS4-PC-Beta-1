"""fifa14: where the match setup reads the STADIUM_ID / BALL_ID settings (for the in-game menu).

The game's match setup reads two developer settings that, when present, replace the stadium and
the ball of the match:

  lea rsi, "STADIUM_ID" ; mov rdi, rax ; call HasKey      ; cmp al, 1 ; jne ...
  call GetIni ; lea rsi, "STADIUM_ID" ; mov rdi, rax ; mov edx, 1 ; call GetInt ; mov [rbp-..], eax

  lea rsi, "BALL_ID" ; mov rdi, rax ; mov edx, ebx ; mov ecx, 1 ; call GetInt ; mov ebx, eax

The menu (gpu/shim/fifa14_match.cpp) replaces those 5-byte calls with `mov al, 1` / `mov eax, id`
while a stadium or ball is chosen, and puts the calls back for "game default". This prints the
guest offsets (ELF addresses) of the calls, for BB_FIFA_MATCH_SITES:

  python scripts/fifa14_match_sites.py "<game dir>/eboot.bin"
  -> stadium_has=0x612c2a,stadium_get=0x612c47,stadium_flag=0x3777bf0,ball=0x8b1392:...

Every site is checked against the expected instruction bytes; nothing is printed when the
executable is another version (exit code 2).
"""
import struct
import sys


def load(path):
    f = open(path, 'rb').read()
    if f[:4] != b'\x7fELF':
        raise ValueError('not an ELF file')
    phoff, = struct.unpack_from('<Q', f, 0x20)
    phnum, = struct.unpack_from('<H', f, 0x38)
    segs = [struct.unpack_from('<IIQQQQQQ', f, phoff + 56 * i) for i in range(phnum)]
    loads = [s for s in segs if s[0] == 1]
    text = next(s for s in loads if s[1] & 1)
    return f, loads, text


def va_of(loads, off):
    for s in loads:
        if s[2] <= off < s[2] + s[5]:
            return s[3] + off - s[2]
    return None


def lea_sites(f, loads, text, name):
    """Code addresses of `lea rsi, [rip + name]` (48 8d 35 disp32)."""
    targets = set()
    pat = b'\0' + name.encode() + b'\0'
    i = f.find(pat)
    while i >= 0:
        targets.add(va_of(loads, i + 1))
        i = f.find(pat, i + 1)
    code = f[text[2]:text[2] + text[5]]
    base = text[3]
    out = []
    i = code.find(b'\x48\x8d\x35')
    while i >= 0:
        disp, = struct.unpack_from('<i', code, i + 3)
        if base + i + 7 + disp in targets:
            out.append((base + i, code, i))
        i = code.find(b'\x48\x8d\x35', i + 1)
    return out


def base_va(text):
    return text[3]


def find(path):
    f, loads, text = load(path)
    stadium_has = stadium_get = stadium_once = None
    for va, code, i in lea_sites(f, loads, text, 'STADIUM_ID'):
        after = code[i + 7:i + 7 + 16]
        # mov rdi, rax ; call HasKey ; cmp al, 1 ; jne
        if after[:3] == b'\x48\x89\xc7' and after[3] == 0xe8 and after[8:10] == b'\x3c\x01' and after[10] == 0x75:
            # the first such pair: HasKey here, then within 0x30 bytes the GetInt with edx = 1
            nxt = code[i:i + 0x40].find(b'\xba\x01\x00\x00\x00\xe8', 16)
            if stadium_has is None and nxt > 0:
                stadium_has = va + 10
                stadium_get = va + nxt + 5
                # The block runs once a session: before it `mov al, [rip + flag] ; test al, al ;
                # jne`, after it `mov byte [rip + flag], 1`. The port clears that flag byte (data),
                # so every match reads the setting again (and each run is logged).
                before = code[i - 0x20:i]
                k = before.rfind(b'\x8a\x05')
                if k >= 0:
                    flag_va = va - 0x20 + k + 6 + struct.unpack_from('<i', before, k + 2)[0]
                    j = code.find(b'\xc6\x05', i, i + 0x100)
                    while j >= 0:
                        if base_va(text) + j + 7 + struct.unpack_from('<i', code, j + 2)[0] == flag_va \
                                and code[j + 6] == 1:
                            stadium_once = flag_va  # the flag byte (data): the port clears it
                            break
                        j = code.find(b'\xc6\x05', j + 1, i + 0x100)
    # The match settings record (the game's own menus, World Cup included): the stadium of the
    # match is read from it by name and stored in the match:
    #   lea rsi, "STADIUM_ID" ; mov rdi, r14 ; call [rax + 0x18] ; mov [rbx + disp32], eax
    # The menu replaces `mov rdi, r14 ; call [rax + 0x18]` (6 bytes) with `mov eax, id ; nop`.
    stadium_record = None
    for va, code, i in lea_sites(f, loads, text, 'STADIUM_ID'):
        after = code[i + 7:i + 7 + 12]
        if after[0] in (0x48, 0x4c) and after[1] == 0x89 and after[3:6] == b'\xff\x50\x18' \
                and after[6:8] == b'\x89\x83':
            if stadium_record is not None:
                raise ValueError('two match settings stadium reads')
            stadium_record = va + 7
    # The stadium of a team (the World Cup's national teams are all linked to the Maracana in
    # wc_ng_db teamstadiumlinks): push rbp ; mov rbp, rsp ; push r15 ; ... ; mov r12d, edi ; ...
    # lea rsi, "stadiumid". The menu replaces its first 6 bytes with `mov eax, id ; ret`.
    team_stadium = None
    for va, code, i in lea_sites(f, loads, text, 'stadiumid'):
        window = code[i - 0x80:i]
        k = window.rfind(b'\x55\x48\x89\xe5\x41\x57')
        if k >= 0 and b'\x41\x89\xfc' in window[k:k + 0x20]:
            start = va - 0x80 + k
            if team_stadium not in (None, start):
                raise ValueError('two team stadium functions')
            team_stadium = start
    # The home team of a stadium (esi stadium, edx default), by a query on the mode's database:
    # with a stadium the World Cup database does not have (Camp Nou...) the query result is null
    # and the game reads through it. The menu makes it `mov eax, edx ; ret` (the default) while a
    # stadium is chosen. Prologue: push rbp ; mov rbp, rsp ; push r15 ; push r14 ; push r12 ;
    # push rbx ; mov r14d, edx ; mov r15d, esi.
    stadium_home = None
    prologue = bytes.fromhex('554889e54157415641545341 89d6 4189f7'.replace(' ', ''))
    for va, code, i in lea_sites(f, loads, text, 'SELECT hometeamid FROM stadiums WHERE stadiumid = %d'):
        window = code[i - 0x80:i]
        k = window.rfind(prologue)
        if k >= 0:
            start = va - 0x80 + k
            if stadium_home not in (None, start):
                raise ValueError('two stadium home team functions')
            stadium_home = start
    # The time of day a stadium has (esi stadium, edx wanted), by a query on the mode's database:
    # with a stadium the World Cup database does not have, every column reads 5 (none) and the
    # match loads stadium 0 with lighting 5 (nothing drawn but the players). The menu makes it
    # return the wanted time (night stays night, anything else is day) while a stadium is chosen.
    # Prologue: push rbp ; mov rbp, rsp ; push r15..rbx ; sub rsp, 0x18 ; mov [rbp-0x2c], edx ;
    # mov ebx, esi.
    stadium_tod = None
    tod_prologue = bytes.fromhex('554889e5415741564155415453 4883ec18 8955d4 89f3'.replace(' ', ''))
    for va, code, i in lea_sites(f, loads, text,
                                 'SELECT timeofday1, timeofday2, timeofday3, timeofday4, isdynamic '
                                 'FROM stadiums WHERE stadiumid = %d'):
        window = code[i - 0x80:i]
        k = window.rfind(tod_prologue)
        if k >= 0:
            start = va - 0x80 + k
            if stadium_tod not in (None, start):
                raise ValueError('two stadium time of day functions')
            stadium_tod = start
    # The match settings screen's stadium choices (settings service GetChoiceListIDs and
    # GetChoiceListDisplayStrings): `call [rax + 0xa8] ; test al, al ; jne <the mode's own list>`
    # asks the mode for its stadiums (the World Cup: the Maracana only); otherwise the list comes
    # from the database (lea rdx, "stadiums" follows). Optional (BB_FIFA_UI_STADIUMS): the
    # addresses of `test al, al`, whose jne the port removes.
    import re
    stadium_list = []
    tables = {va_of(loads, m.start() + 1) for m in re.finditer(rb'\0stadiums\0', f)}
    code = f[text[2]:text[2] + text[5]]
    for m in re.finditer(re.escape(bytes.fromhex('ff90a800000084c00f85')), code):
        i = m.start() + 6
        window = code[i:i + 0x100]
        for k in range(len(window) - 7):
            if window[k:k + 3] == b'\x48\x8d\x15':
                disp, = struct.unpack_from('<i', window, k + 3)
                if text[3] + i + k + 7 + disp in tables:
                    stadium_list.append(text[3] + i)
                    break
    balls = []
    for va, code, i in lea_sites(f, loads, text, 'BALL_ID'):
        after = code[i + 7:i + 7 + 24]
        # mov rdi, rax ; mov edx, ebx ; mov ecx, 1 ; call GetInt ; mov ebx, eax
        if after[:3] == b'\x48\x89\xc7' and after[3:5] == b'\x89\xda' and after[5:10] == b'\xb9\x01\x00\x00\x00' \
                and after[10] == 0xe8 and after[15:17] == b'\x89\xc3':
            balls.append(va + 7 + 10)
    if not (stadium_has and stadium_get and stadium_once and stadium_record and team_stadium and
            stadium_home and stadium_tod and balls):
        raise ValueError(f'sites not found (stadium {stadium_has}, {stadium_get}, {stadium_once}, '
                         f'{stadium_record}, {team_stadium}, {stadium_home}, {stadium_tod}; '
                         f'balls {balls})')
    return (stadium_has, stadium_get, stadium_once, stadium_record, team_stadium, stadium_home,
            stadium_tod, stadium_list, balls)


if __name__ == '__main__':
    try:
        has, get, once, record, team, home, tod, slist, balls = find(sys.argv[1])
    except (ValueError, OSError, StopIteration) as e:
        print(f'fifa14_match_sites: {e}', file=sys.stderr)
        sys.exit(2)
    print(f'stadium_has={has:#x},stadium_get={get:#x},stadium_flag={once:#x},'
          f'stadium_record={record:#x},team_stadium={team:#x},stadium_home={home:#x},'
          f'stadium_tod={tod:#x},' +
          ('stadium_list=' + ':'.join(f'{a:#x}' for a in slist) + ',' if slist else '') + 'ball=' +
          ':'.join(f'{b:#x}' for b in balls))
