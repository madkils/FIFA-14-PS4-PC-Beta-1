#!/usr/bin/env python3
"""fifa14: prepare and start FIFA 14 from any copy of the game, without MSYS2 (the Beta package).

    python scripts/fifa14_run.py --game <game folder> [--update <update folder>] --data <folder>
                                 [--exe bin/sacredfire-game.exe] [--check] [-- extra game args]

The same steps as scripts/windows/run-fifa14.sh, for folders chosen in the launcher:

- <game folder> / <update folder>: the root of a dump, an extracted PKG or a mounted ISO (the
  folder holding eboot.bin and sce_sys). Executables may be decrypted ELF files or fake-signed
  SELF files (what dumpers and backup PKGs hold); console-encrypted SELF files are refused with a
  message (only a console can decrypt them). The update is optional.
- The run folders live in <data> (hard links to the game files when on the same drive, copies
  otherwise), so the game's own files are never changed; prepared images, saves and logs too.
- Options come from the environment the launcher sets (BB_FULLSCREEN, BB_WINDOW_SIZE, BB_FIFA_RES,
  BB_FIFA_MSAA, BB_FIFA_STADIUM, BB_FIFA_BALL, BB_VBLANK_HZ, BB_FIFA_UNLOCK, ...).

--check only reports what the folders hold (one JSON line) and exits: the launcher shows it.
Exit codes: 0 the game closed normally, 2 the folders are not usable, others: the game's own.
"""
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import fifa14_exec  # noqa: E402

DLLS = ['dlc/dlc_powdll/dlc/powdll/powdllzf.prx',
        'dlc/dlc_FootballCompEng/dlc/FootballCompEng/FootballCompEngzf.prx']


class Unusable(Exception):
    pass


def log(msg):
    print(f'fifa14_run: {msg}', flush=True)


def find_root(folder, need_sfo=True):
    """The folder holding eboot.bin (and sce_sys/param.sfo for the game; update dumps may lack
    it): the given one or one up to three levels below it."""
    folder = Path(folder)
    if not folder.is_dir():
        raise Unusable(f'pasta não encontrada: {folder}')
    for depth in range(4):
        pattern = '/'.join(['*'] * depth + ['eboot.bin']) if depth else 'eboot.bin'
        for eboot in sorted(folder.glob(pattern)):
            if not need_sfo or (eboot.parent / 'sce_sys' / 'param.sfo').is_file():
                return eboot.parent
    raise Unusable(f'não há eboot.bin' + (' com sce_sys/param.sfo' if need_sfo else '') + f' em {folder}')


def sfo_info(root):
    from prepare import sfo
    try:
        values = sfo((root / 'sce_sys' / 'param.sfo').read_bytes())
    except Exception:
        return {}
    return {k: values.get(k) for k in ('TITLE', 'TITLE_ID', 'APP_VER', 'VERSION', 'CATEGORY')}


def executables(root):
    """(relative path, kind) of every executable of the folder."""
    out = []
    for p in root.rglob('*'):
        # sce_sys holds the console's own modules (about/right.sprx): the game never loads them
        if 'sce_sys' in p.relative_to(root).parts[:1]:
            continue
        if p.is_file() and fifa14_exec.is_executable_name(p.name):
            out.append((p.relative_to(root).as_posix(), fifa14_exec.kind(p)))
    return out


def describe(folder, update):
    """What the launcher shows: title, id, version, executables, problems."""
    info = {'game': None, 'update': None, 'problems': []}
    for key, path in (('game', folder), ('update', update)):
        if not path:
            continue
        try:
            root = find_root(path, need_sfo=key == 'game')
        except Unusable as e:
            info['problems'].append(str(e))
            continue
        exe = executables(root)
        encrypted = [r for r, k in exe if k == 'encrypted']
        entry = dict(root=str(root), **sfo_info(root), executables=len(exe), encrypted=encrypted)
        entry['worldcup'] = (root / 'data_worldcup.big').is_file()
        info[key] = entry
        if encrypted:
            info['problems'].append(
                f'{key}: executáveis criptografados pelo console ({", ".join(encrypted[:3])}): '
                'use um dump feito com decriptação')
        if entry.get('TITLE_ID') and not str(entry['TITLE_ID']).startswith('CUSA'):
            info['problems'].append(f'{key}: TITLE_ID inesperado {entry["TITLE_ID"]}')
    if info['update'] and info['update'].get('CATEGORY') not in (None, 'gp'):
        info['problems'].append('a pasta escolhida como update não é um update (categoria '
                                f'{info["update"].get("CATEGORY")})')
    return info


def place(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() or dst.is_symlink():
        dst.unlink()
    try:
        os.link(src, dst)
        return True
    except OSError:
        shutil.copy2(src, dst)
        return False


def stamp_of(*roots):
    """Changes when a source folder changes (its files' count, sizes and newest time)."""
    parts = []
    for root in roots:
        count = size = newest = 0
        for p in root.rglob('*'):
            if p.is_file():
                st = p.stat()
                count += 1
                size += st.st_size
                newest = max(newest, int(st.st_mtime))
        parts.append(f'{root}|{count}|{size}|{newest}')
    return '\n'.join(parts)


def build_run_folder(game_root, update_root, run):
    """run = the game's files (+ the update's over them), as links; rebuilt when a source changes."""
    stamp_file = run / '.fifa14-run-stamp'
    stamp = stamp_of(*(r for r in (game_root, update_root) if r))
    if stamp_file.is_file() and stamp_file.read_text(encoding='utf-8') == stamp:
        return
    log(f'montando a pasta do jogo em {run} (só na primeira vez ou quando os arquivos mudam)')
    if run.exists():
        shutil.rmtree(run)
    copied = 0
    by_name = {}
    for p in game_root.rglob('*'):
        if p.is_file():
            rel = p.relative_to(game_root)
            copied += not place(p, run / rel)
            by_name.setdefault(p.name.lower(), []).append(rel)
    if update_root:
        for p in update_root.rglob('*'):
            if not p.is_file():
                continue
            rel = p.relative_to(update_root)
            if fifa14_exec.is_executable_name(p.name) and fifa14_exec.kind(p) == 'encrypted':
                log(f'AVISO: {rel} do update está criptografado; fica o do jogo base')
                continue
            if not (game_root / rel).exists() and len(by_name.get(p.name.lower(), [])) == 1:
                rel = by_name[p.name.lower()][0]  # libc.prx -> sce_module/libc.prx
            copied += not place(p, run / rel)
    if copied:
        log(f'{copied} arquivos copiados (pasta do jogo em outro disco: sem links)')
    stamp_file.write_text(stamp, encoding='utf-8')


def write_user_ini(run):
    """The unlock settings and the launcher's stadium/ball (as run-fifa14.sh does)."""
    path = run / 'user.ini'
    if os.environ.get('BB_FIFA_UNLOCK', '1') != '1':
        if path.exists():
            path.unlink()
        return
    lines = ['// fifa14 port: all content unlocked (written by fifa14_run.py; BB_FIFA_UNLOCK=0 removes it)',
             'UNLOCK_ALL_UCC=1', '[DLC]', 'SHOW_ALL_ITEMS=1', '[POW]', 'ENABLE_ALL_UNLOCKABLES=1', '[]']
    extra = os.environ.get('BB_FIFA_INI', '').replace(',', ' ').split()
    if os.environ.get('BB_FIFA_STADIUM'):
        extra.append('STADIUM_ID=' + os.environ['BB_FIFA_STADIUM'])
    if os.environ.get('BB_FIFA_BALL'):
        extra.append('BALL_ID=' + os.environ['BB_FIFA_BALL'])
    for kv in extra:
        key, _, value = kv.partition('=')
        if '/' in key:
            section, _, name = key.rpartition('/')
            lines += [f'[{section}]', f'{name}={value}', '[]']
        else:
            lines.append(kv)
    if path.exists():
        path.unlink()  # a hard link would write through to the game's own file
    path.write_bytes(('\r\n'.join(lines) + '\r\n').encode('utf-8'))


def py(*args, capture=False):
    """Runs one of the preparation scripts with this same Python."""
    cmd = [sys.executable, *map(str, args)]
    if capture:
        r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, encoding='utf-8', errors='replace')
        if r.returncode:
            raise Unusable(f'{Path(str(args[0])).name}: {r.stderr.strip() or r.stdout.strip()}')
        return r.stdout.strip()
    if subprocess.run(cmd, cwd=ROOT).returncode:
        raise Unusable(f'{Path(str(args[0])).name} falhou')
    return ''


def main(argv):
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--game', required=True)
    ap.add_argument('--update')
    ap.add_argument('--data', required=True)
    ap.add_argument('--exe', default=str(ROOT / 'bin' / 'sacredfire-game.exe'))
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--copy', action='store_true', help='the game is on read-only media (ISO): copy it into --data')
    ap.add_argument('rest', nargs='*')
    a = ap.parse_args(argv)
    info = describe(a.game, a.update)
    if a.check:
        print(json.dumps(info))
        return 0 if info['game'] and not info['problems'] else 2
    if info['problems'] or not info['game']:
        for p in info['problems']:
            log('ERRO: ' + p)
        return 2
    data = Path(a.data).resolve()
    game_root = Path(info['game']['root'])
    update_root = Path(info['update']['root']) if info['update'] else None
    name = 'update' if update_root else 'base'
    # The run folder holds hard links to the game's files, which only work on the game's own
    # drive: on another drive than <data>, it goes to <that drive>\FIFA14-PC-dados (no extra space).
    run_base = data
    game_drive = os.path.splitdrive(str(game_root))[0].upper()
    if game_drive and game_drive != os.path.splitdrive(str(data))[0].upper() and not a.copy:
        run_base = Path(game_drive + '/') / 'FIFA14-PC-dados'
    run = run_base / f'jogo-{name}'
    out = data / f'preparado-{name}'
    user = data / f'saves-{name}' / 'user'
    logs = data / 'logs'
    for d in (out, user, logs):
        d.mkdir(parents=True, exist_ok=True)
    build_run_folder(game_root, update_root, run)
    if update_root and (run / 'data_worldcup.big').is_file():
        try:
            py(HERE / 'fifa14_wc_stadiums.py', run, ROOT / 'launcher' / 'fifa14-assets.tsv')
        except Unusable as e:
            log(f'AVISO: estádios da Copa não adicionados ({e})')
    elif update_root:
        log('AVISO: o update não tem data_worldcup.big (dump incompleto): a Copa fica na tela de carregamento')
    write_user_ini(run)

    profile = py(HERE / 'game_check.py', run, capture=True)
    if profile != 'fifa14':
        raise Unusable(f'esta cópia não é a versão suportada do FIFA 14 ({profile})')
    env = dict(os.environ)
    env['BB_GAME_PROFILE'] = 'fifa14'
    try:
        env['BB_GAME_VARIANT'] = py(HERE / 'game_check.py', run, '--variant', capture=True)
    except Unusable:
        env['BB_GAME_VARIANT'] = '?'
    py(HERE / 'prepare.py', run, '--out', out)
    lazy = [d for d in DLLS if (run / d).is_file()] if env.get('BB_FIFA_DLLS', '1') == '1' else []
    py(HERE / 'link_modules.py', run, '--out', out, '--modules', 'libc.prx', 'libSceFios2.prx',
       *(['--lazy', *lazy] if lazy else []))
    if env.get('BB_FIFA_RES') or env.get('BB_FIFA_MSAA') or env.get('BB_FIFA_60') == '1':
        args = [HERE / 'fifa14_render_patch.py', out / 'boot-linked.bin', '--size',
                env.get('BB_FIFA_RES') or '1920x1080', '--msaa', env.get('BB_FIFA_MSAA') or '0']
        if env.get('BB_FIFA_60') == '1':
            args.append('--menus60')
        text = py(*args, capture=True)
        for line in text.splitlines():
            if line.startswith('dmem_extra_mb='):
                extra = int(line.split('=', 1)[1] or 0)
                if extra > 0 and 'BB_DMEM_MB' not in env:
                    env['BB_DMEM_MB'] = str(5056 + extra)
            else:
                log(line)
    for script, key in (('fifa14_settings_sites.py', 'BB_FIFA_SETTINGS_SITES'),
                        ('fifa14_match_sites.py', 'BB_FIFA_MATCH_SITES')):
        try:
            env[key] = py(HERE / script, run / 'eboot.bin', capture=True)
        except Unusable as e:
            log(f'AVISO: {e}')
    env['BB_FIFA_ASSETS'] = str(ROOT / 'launcher' / 'fifa14-assets.tsv')
    env.setdefault('BB_FIFA_LAUNCHER_INI', str(ROOT / 'fifa14-launcher.ini'))
    py(ROOT / 'tools' / 'gen_import_names.py', '--out', out, '--aerolib', ROOT / 'share' / 'aerolib.inl')
    py(HERE / 'content_profile.py', run, '--out', out, '--sku', env.get('BB_CONTENT_SKU', 'full'))
    # Ignite engine defaults (run-fifa14.sh)
    for k, v in (('BB_READBACKS', '2'), ('BB_READBACK_LINEAR', '1'), ('BB_GPU_WRITE_TWINS', '0'),
                 ('BB_Z16S8_AS_D16', '1'), ('BB_NEO', '0'), ('BB_MENU_LANGUAGE', 'pt')):
        env.setdefault(k, v)
    env['BB_LOG_DIR'] = str(out)
    logfile = logs / f'jogo-{name}-{time.strftime("%Y%m%d-%H%M%S")}.log'
    log(f'iniciando o jogo (log: {logfile})')
    cmd = [str(Path(a.exe).resolve()), str(out / 'boot-linked.bin'), '--import-names', str(out / 'import_names.txt'),
           '--content-profile', str(out / 'content.bin'), '--app0', str(run), '--user', str(user),
           '--timeout', env.get('BB_TIMEOUT', '0'), *a.rest]
    with open(logfile, 'wb') as f:
        code = subprocess.run(cmd, cwd=ROOT, env=env, stdout=f, stderr=subprocess.STDOUT).returncode
    with open(logfile, 'ab') as f:
        f.write(f'fifa14_run: exit code {code} (0x{code & 0xffffffff:X})\n'.encode())
    log(f'o jogo fechou (código {code})')
    return code


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except AttributeError:
        pass
    try:
        sys.exit(main(sys.argv[1:]))
    except Unusable as e:
        log(f'ERRO: {e}')
        sys.exit(2)
