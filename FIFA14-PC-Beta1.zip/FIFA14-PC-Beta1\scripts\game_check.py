#!/usr/bin/env python3
"""The game files this port runs, keyed on the executable's loaded image.

Profile: EA SPORTS UFC 3 CUSA06534 (EU) with the 1.14 update merged in. The check
compares the loaded executable image, whose hash is the same whatever tool dumped it (the SELF
headers around it differ). BB_SKIP_GAME_CHECK=1 skips it. bbport's Bloodborne profile was removed
on 2026-10-09.

Two builds of the 1.21 update exist: the one rebuilt for firmware 5.05 (sdk_ver=05050000 in
param.sfo; the image in SUPPORTED) and the original one for firmware 6.72+ (KNOWN_672 holds its
image hash). Same game, different executable. A 1.21 executable that is not a known old one is
accepted as `variant='6.72+'`: patches.py finds its patch sites by signature instead of address,
and the address-keyed diagnostics (which know the 5.05 build's addresses) stay off.
"""
import hashlib
import os
import sys
from pathlib import Path

# image sha256 -> profile. `name` is what the runtime and the GPU menu read (BB_GAME_PROFILE);
# `modules` are the sce_module PRXs link_modules.py links natively; `patches` says whether
# patches.py has a patch file for it.
SUPPORTED = {
    '46c2477702ae5d3fbff3a1911f10841aa150d20941d515ffb3edec75153f055b': dict(
        name='ufc3', title='CUSA06534', version='01.14', game='EA SPORTS UFC 3', update='CUSA06534-patch',
        modules=('libc.prx', 'libSceFios2.prx'), patches=False),
    # fifa14: FIFA 14 CUSA00111 (US), base game 01.00 (disc dump). Ignite engine, as UFC 3.
    '421e2d06b338347ad180cd9ee4f576464f7db1a95de9292c637c3817f1ef1e95': dict(
        name='fifa14', title='CUSA00111', version='01.00', game='FIFA 14', update='CUSA00111-patch',
        modules=('libc.prx', 'libSceFios2.prx'), patches=False),
    # fifa14: the same game with its last update's executable (built Apr 29 2014, has the World
    # Cup screens; the user knows it as 1.05, the dump has no param.sfo to confirm the number).
    # Optional: scripts/fifa14_update_dir.py builds its run folder, BB_FIFA_UPDATE=1 runs it.
    'd77b1e11d87454c457362f97602e84726f2221a760e3f4059b71896a72158fae': dict(
        name='fifa14', title='CUSA00111', version='01.05', game='FIFA 14', update='CUSA00111-patch',
        modules=('libc.prx', 'libSceFios2.prx'), patches=False),
}
BY_TITLE = {p['title']: p for p in SUPPORTED.values()}
# Images that are known NOT to be 1.14: the base game's executable (1.00). With a 1.14 param.sfo
# these mean the update's eboot.bin was not copied in.
OLD_IMAGES = {
    '1dc99716a77f5411834d004d6becc3c829e382a244aa0dcbd63932a7eeee0bf1': '01.00',
}
# Other builds of the supported update (none known for UFC 3).
KNOWN_672 = set()
# Plain-text files the game parses before main() (path -> lines a readable copy has). memory.cfg
# declares the allocators and categories ("Sys" among them): read but unusable (blank, binary, a
# compressed PFS block left by a bad extraction), no category exists and the first allocation calls
# through a vtable that is not one, an execute fault at 0x1 under guest 0xcc1 (GitHub #31).
CONFIG_FILES = {
    'samplegame/data/common/config/memory.cfg': ('AddAllocatorContainer.kettle', 'AddCategory'),
    'samplegame/data/common/config/videoheap.cfg': ('AddAllocator.kettle',),
}
SUPPORTED_TITLE = 'CUSA06534'
SUPPORTED_VERSION = '01.14'
SUPPORTED_IMAGE = '46c2477702ae5d3fbff3a1911f10841aa150d20941d515ffb3edec75153f055b'


def image_sha256(game):
    """The SHA-256 of eboot.bin's loaded image (its loadable segments at their addresses)."""
    from prepare import parse_self, span  # same directory
    elf, header, ph, _segments, _missing = parse_self((Path(game) / 'eboot.bin').read_bytes())
    loads = [p for p in ph if p['type'] in (1, 0x61000010)]
    image = bytearray(max(p['vaddr'] + p['memsz'] for p in loads))
    for p in loads:
        image[p['vaddr']:p['vaddr'] + p['filesz']] = span(elf, p['offset'], p['filesz'])
    return hashlib.sha256(image).hexdigest()


def profile(game, image_hash=None):
    """The profile dict for a supported game folder, else None (BB_SKIP_GAME_CHECK=1: a profile
    guessed from param.sfo's TITLE_ID when one exists, so run.sh can still branch)."""
    try:
        image_hash = image_hash or image_sha256(game)
    except (OSError, ValueError, IndexError, StopIteration, KeyError):
        image_hash = None
    if image_hash in SUPPORTED:
        return dict(SUPPORTED[image_hash], variant='5.05')
    if image_hash and executable_problem(game, image_hash) is None and os.environ.get('BB_SKIP_GAME_CHECK') != '1':
        info = sfo_info(game)
        return dict(BY_TITLE[info['TITLE_ID']], variant='6.72+', known=image_hash in KNOWN_672)
    if os.environ.get('BB_SKIP_GAME_CHECK') != '1':
        return None
    info = sfo_info(game)
    found = BY_TITLE.get(info.get('TITLE_ID'))
    return dict(found, variant='?') if found else None


def sfo_info(game):
    from prepare import sfo
    try:
        return sfo((Path(game) / 'sce_sys/param.sfo').read_bytes())
    except (OSError, ValueError, IndexError):
        return {}


def damaged_configs(game):
    """The CONFIG_FILES that are missing or not the plain text the game parses (UFC 3 only)."""
    damaged = []
    if sfo_info(game).get('TITLE_ID') != SUPPORTED_TITLE:
        return damaged  # fifa14: CONFIG_FILES are UFC 3 paths
    for name, markers in CONFIG_FILES.items():
        try:
            data = (Path(game) / name).read_bytes()
        except OSError:
            damaged.append(name)
            continue
        if b'\0' in data or not all(m.encode() in data for m in markers):
            damaged.append(name)
    return damaged


def problem(game, image_hash=None):
    """None for a supported game, else (kind, title, version[, detail]): kind is 'missing_update'
    (base game or an older update), 'wrong_eboot' (param.sfo names the supported update, eboot.bin
    is another version), 'other_title' (another edition, region or game), 'unreadable' or
    'damaged_files' (detail: the game files that are missing or damaged)."""
    found = executable_problem(game, image_hash)
    if found:
        return found
    if os.environ.get('BB_SKIP_GAME_CHECK') == '1':
        return None
    damaged = damaged_configs(game)
    if damaged:
        info = sfo_info(game)
        return 'damaged_files', info.get('TITLE_ID', '?'), info.get('APP_VER', '?'), damaged
    return None


def executable_problem(game, image_hash=None):
    """problem() for eboot.bin and param.sfo alone."""
    if os.environ.get('BB_SKIP_GAME_CHECK') == '1':
        return None
    from prepare import sfo
    try:
        info = sfo((Path(game) / 'sce_sys/param.sfo').read_bytes())
    except (OSError, ValueError, IndexError):
        info = {}
    title, version = info.get('TITLE_ID', '?'), info.get('APP_VER', '?')
    try:
        image_hash = image_hash or image_sha256(game)
    except (OSError, ValueError, IndexError, StopIteration, KeyError):
        return 'unreadable', title, version
    if image_hash in SUPPORTED:
        return None
    if title not in BY_TITLE:
        return 'other_title', title, version
    if version != BY_TITLE[title]['version']:
        return 'missing_update', title, version
    if image_hash in OLD_IMAGES:
        return 'wrong_eboot', title, version
    return None  # another 1.21 build (6.72+): accepted, see the module docstring


def explain(kind, title, version, detail=None):
    """What is wrong and what to do, for the log (English)."""
    found = f'Found {title} version {version} (sce_sys/param.sfo).'
    p = BY_TITLE.get(title, BY_TITLE[SUPPORTED_TITLE])
    supported = ', '.join(f"{q['game']} {q['title']} {q['version']}" for q in SUPPORTED.values())
    return {
        'missing_update': f"{found} The port needs the {p['version']} update merged into the game folder: copy "
                          f"everything from the dumped {p['version']} update (e.g. {p['update']}) into the "
                          'game folder, replacing files (eboot.bin and sce_sys too).',
        'wrong_eboot': f"{found} param.sfo is from {p['version']} but eboot.bin is not: copy eboot.bin from "
                       f"the dumped {p['version']} update into the game folder, replacing the old one.",
        'other_title': f'{found} Supported: {supported}; other editions and regions have a different executable.',
        'unreadable': f'{found} eboot.bin could not be read as a decrypted PS4 executable: dump '
                      'the game and its update again.',
        'damaged_files': f"{found} These game files are missing or damaged (not the plain text the game "
                         f"reads): {', '.join(detail or [])}. The game would close at start. Extract the "
                         f"game and the {p['version']} update again (a fully decrypted dump) and copy the "
                         'files over, replacing the old ones.',
    }[kind]


if __name__ == '__main__':
    # game_check.py GAME_DIR: prints the profile name (run.sh branches on it), or fails with the
    # reason. With --variant: the update build instead ("5.05", "6.72+", or "?" when the check
    # is skipped), for BB_GAME_VARIANT.
    args = [a for a in sys.argv[1:] if a != '--variant']
    game = Path(args[0]) if args else Path('.')
    found = problem(game)
    if found:
        sys.exit('Unsupported game files: ' + explain(*found))
    p = profile(game)
    if '--variant' in sys.argv:
        print(p.get('variant', '?') if p else '?')
    else:
        print(p['name'] if p else 'unknown')
