"""fifa14: what kind of executable a game file is, for the folder preparation scripts.

  elf        a decrypted executable (dumped with decryption, or the separate decrypted copies)
  fself      a PS4 SELF whose segments are plain (fake-signed: backup PKGs, homebrew); the port's
             preparation (prepare.py, link_modules.py) reads it as it is
  encrypted  a PS4 SELF with encrypted segments (the console's own files): it needs a decrypted
             copy, which only a console can make
  data       anything else
"""
import struct

SELF_MAGIC = b'O\x15=\x1d'
ELF_MAGIC = b'\x7fELF'


def kind(path):
    with open(path, 'rb') as f:
        head = f.read(32)
        if head[:4] == ELF_MAGIC:
            return 'elf'
        if head[:4] != SELF_MAGIC or len(head) < 32:
            return 'data'
        count, = struct.unpack_from('<H', head, 24)
        table = f.read(count * 32)
    if len(table) < count * 32:
        return 'encrypted'  # damaged: treated as unusable
    for i in range(count):
        flags, = struct.unpack_from('<Q', table, i * 32)
        # the same test as prepare.parse_self: a blocked-in segment that is encrypted or compressed
        if flags & 0x800 and flags & 10:
            return 'encrypted'
    return 'fself'


def is_executable_name(name):
    name = name.lower()
    return name == 'eboot.bin' or name.endswith(('.prx', '.sprx', '.elf', '.self'))
