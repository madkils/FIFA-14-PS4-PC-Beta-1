#!/usr/bin/env python3
"""fifa14: every stadium of the port's list also exists in the World Cup database.

    python fifa14_wc_stadiums.py <update run folder> <launcher/fifa14-assets.tsv>

Matches set up from the World Cup menus read the stadium's record (times of day, pitch, nets...)
from data/db/wc_ng_db.db inside data_worldcup.big. That database only has the World Cup venues and
a few others: a stadium chosen in the port's menu that it lacks (Old Trafford, Camp Nou...) gets an
empty record, and the match loads "stadium 0" with lighting 5 (only the players are drawn).

This copies the missing stadiums' records from the main database (data/db/fifa_ng_db.db in
data_startup.big) into the World Cup one, and writes the result into a copy of data_worldcup.big
(+ .bh) in the run folder: the new database is appended and its BIG / .bh entries repointed. The
dump is never written to (the run folder's hard link is replaced by a file of its own).

The home team of an added stadium is the national team the World Cup database links to another
stadium of the same country (Brazil otherwise): its own clubs do not exist in that database.

Database layout (little endian): 'DB\\0\\x08', 0, u32 size, 0, u32 tables, u32 crc of the first
0x14 bytes; per table (4-char short name, u32 offset after the directory), u32 crc of the
directory. A table: header of 0x20 bytes (u16 records / valid at 0x10 / 0x12, u8 fields at 0x18)
+ u32 crc of it, 16-byte field definitions (type, bit offset, short name, depth), the records,
u32 crc of definitions + records. CRC-32/MPEG-2 (polynomial 0x04C11DB7, init 0xffffffff, no
reflection, no final xor). Integer fields are bit-packed LSB first, stored as value - rangelow.
BIG4 entries of these files are "chunkzip": raw deflate blocks.
"""
import os
import re
import shutil
import struct
import sys
import zlib
from pathlib import Path

WC_BIG = 'data_worldcup.big'
WC_DB, WC_META = 'data/db/wc_ng_db.db', 'data/db/wc_ng_db-meta.xml'
MAIN_BIG = 'data_startup.big'
MAIN_DB, MAIN_META = 'data/db/fifa_ng_db.db', 'data/db/fifa_ng_db-meta.xml'
STAMP = '.wc-stadiums'
BRAZIL_STADIUM = 276

_TABLE = []
for _i in range(256):
    _c = _i << 24
    for _ in range(8):
        _c = ((_c << 1) ^ 0x04C11DB7) & 0xffffffff if _c & 0x80000000 else (_c << 1) & 0xffffffff
    _TABLE.append(_c)


def crc(data):
    c = 0xffffffff
    for x in data:
        c = ((c << 8) & 0xffffffff) ^ _TABLE[((c >> 24) ^ x) & 0xff]
    return c


# ---- BIG4 archives ----
def big_entries(path):
    with open(path, 'rb') as f:
        head = f.read(16)
        if head[:4] != b'BIG4':
            raise ValueError(f'{path}: not a BIG4 archive')
        count, header = struct.unpack('>II', head[8:16])
        d = f.read(header)
    out, p = {}, 0
    for _ in range(count):
        off, size = struct.unpack_from('>II', d, p)
        e = d.index(b'\0', p + 8)
        out[d[p + 8:e].decode('latin1')] = (off, size, 16 + p)
        p = e + 1
    return out


def chunkzip_decode(data):
    if data[:8] != b'chunkzip':
        return data
    _ver, usize, _block, nseg, align = struct.unpack_from('>5I', data, 8)
    out, p = bytearray(), 28
    for _ in range(nseg):
        p += (-(p + 8)) % align
        size, kind = struct.unpack_from('>II', data, p)
        chunk = data[p + 8:p + 8 + size]
        out += zlib.decompress(chunk, -15) if kind == 1 else chunk
        p += 8 + size
    if len(out) != usize:
        raise ValueError('chunkzip: size mismatch')
    return bytes(out)


def chunkzip_encode(data, block=0x2d000, align=0x10):
    chunks = [data[i:i + block] for i in range(0, len(data), block)]
    out = bytearray(b'chunkzip' + struct.pack('>5I', 2, len(data), block, len(chunks), align))
    for c in chunks:
        while (len(out) + 8) % align:
            out.append(0)
        z = zlib.compressobj(9, zlib.DEFLATED, -15)
        packed = z.compress(c) + z.flush()
        out += struct.pack('>II', len(packed), 1) + packed
    return bytes(out)


def big_read(path, name):
    off, size, _ = big_entries(path)[name]
    with open(path, 'rb') as f:
        f.seek(off)
        return chunkzip_decode(f.read(size))


# ---- databases ----
class Table:
    def __init__(self, db, offset, meta, name):
        self.offset = offset
        d = db
        _, self.recbytes, _, _, self.nrec, self.nvalid, _, _, nfields = struct.unpack_from(
            '<IIIIHHHHB', d, offset)
        m = re.search(r'<table name="%s" shortname="(\w+)".*?</table>' % re.escape(name), meta, re.S)
        self.short = m.group(1)
        fmeta = {f[1]: (f[0], int(f[2])) for f in re.findall(
            r'<field name="(\w+)" shortname="(\w+)"[^>]*?rangelow="(-?\d+)"', m.group(0))}
        self.fields = []  # (name, type, bit, depth, rangelow)
        p = offset + 0x24
        for i in range(nfields):
            typ, bit, sn, depth = struct.unpack_from('<II4sI', d, p + 16 * i)
            fname, low = fmeta[sn.decode('latin1')]
            self.fields.append((fname, typ, bit, depth, low))
        self.records = offset + 0x24 + 16 * nfields
        self.end = self.records + self.recbytes * self.nrec

    def rows(self, d):
        out = []
        for r in range(self.nvalid):
            out.append(self.decode(d[self.records + r * self.recbytes:self.records + (r + 1) * self.recbytes]))
        return out

    def decode(self, rec):
        val = int.from_bytes(rec, 'little')
        row = {}
        for name, typ, bit, depth, low in self.fields:
            if typ == 0:
                row[name] = rec[bit // 8:bit // 8 + depth // 8].split(b'\0')[0]
            else:
                row[name] = ((val >> bit) & ((1 << depth) - 1)) + low
        return row

    def encode(self, row):
        val, strings = 0, []
        for name, typ, bit, depth, low in self.fields:
            if typ == 0:
                s = row[name][:depth // 8 - 1]
                strings.append((bit // 8, s + b'\0' * (depth // 8 - len(s))))
            else:
                raw = row[name] - low
                if not 0 <= raw < (1 << depth):
                    raise ValueError(f'{name}={row[name]} does not fit')
                val |= raw << bit
        rec = bytearray(val.to_bytes(self.recbytes, 'little'))
        for at, s in strings:
            rec[at:at + len(s)] = s
        return bytes(rec)


def db_directory(d):
    n, = struct.unpack_from('<I', d, 0x10)
    base = 0x18 + 8 * n + 4
    return n, base, [(d[0x18 + 8 * i:0x1c + 8 * i].decode('latin1'),
                      struct.unpack_from('<I', d, 0x1c + 8 * i)[0]) for i in range(n)]


def db_table(d, meta, name):
    _, base, entries = db_directory(d)
    short = re.search(r'<table name="%s" shortname="(\w+)"' % re.escape(name), meta).group(1)
    off = next(o for s, o in entries if s == short)
    return Table(d, base + off, meta, name)


def db_with_records(d, table, records):
    """The database with the table's records replaced (count may grow); CRCs and offsets redone."""
    n, base, entries = db_directory(d)
    old_len = table.recbytes * table.nrec
    delta = len(records) * table.recbytes - old_len
    count = len(records)
    out = bytearray(d[:table.records]) + b''.join(records) + bytes(4) + d[table.end + 4:]
    struct.pack_into('<HH', out, table.offset + 0x10, count, count)
    struct.pack_into('<I', out, table.offset + 0x20, crc(out[table.offset:table.offset + 0x20]))
    end = table.records + count * table.recbytes
    struct.pack_into('<I', out, end, crc(out[table.offset + 0x24:end]))
    rel = table.offset - base
    for i, (s, o) in enumerate(entries):
        if o > rel:
            struct.pack_into('<I', out, 0x1c + 8 * i, o + delta)
    struct.pack_into('<I', out, 0x18 + 8 * n, crc(out[0x18:0x18 + 8 * n]))
    struct.pack_into('<I', out, 0x8, len(out))
    struct.pack_into('<I', out, 0x14, crc(out[:0x14]))
    return bytes(out)


def build(game, assets):
    game = Path(game)
    wc_big = game / WC_BIG
    wc_db = big_read(wc_big, WC_DB)
    wc_meta = big_read(wc_big, WC_META).decode('utf-8', 'replace')
    main_db = big_read(game / MAIN_BIG, MAIN_DB)
    main_meta = big_read(game / MAIN_BIG, MAIN_META).decode('utf-8', 'replace')

    wc_t = db_table(wc_db, wc_meta, 'stadiums')
    main_t = db_table(main_db, main_meta, 'stadiums')
    wc_rows = wc_t.rows(wc_db)
    main_rows = {r['stadiumid']: r for r in main_t.rows(main_db)}
    have = {r['stadiumid'] for r in wc_rows}
    wanted = []
    for line in Path(assets).read_text(encoding='utf-8').splitlines():
        parts = line.split('\t')
        if len(parts) >= 2 and parts[0] == 'stadium' and parts[1].lstrip('-').isdigit():
            wanted.append(int(parts[1]))
    home_by_country = {}
    for r in wc_rows:
        home_by_country.setdefault(r['countrycode'], r['hometeamid'])
    brazil = next(r['hometeamid'] for r in wc_rows if r['stadiumid'] == BRAZIL_STADIUM)

    added = []
    records = [wc_db[wc_t.records + i * wc_t.recbytes:wc_t.records + (i + 1) * wc_t.recbytes]
               for i in range(wc_t.nvalid)]
    for sid in wanted:
        if sid in have or sid not in main_rows:
            continue
        row = dict(main_rows[sid])
        for name, *_ in wc_t.fields:
            row.setdefault(name, 0)
        row['hometeamid'] = home_by_country.get(row['countrycode'], brazil)
        records.append(wc_t.encode(row))
        added.append((sid, row['name'].decode('latin1')))
    if not added:
        return wc_db, []
    # The key order of the original table is kept (sorted by stadiumid).
    keyed = [(wc_t.decode(r)['stadiumid'], r) for r in records]
    if [k for k, _ in keyed[:wc_t.nvalid]] == sorted(k for k, _ in keyed[:wc_t.nvalid]):
        keyed.sort(key=lambda kr: kr[0])
    new_db = db_with_records(wc_db, wc_t, [r for _, r in keyed])
    # Self-check: the new table reads back with every row.
    check = db_table(new_db, wc_meta, 'stadiums')
    ids = [r['stadiumid'] for r in check.rows(new_db)]
    if len(ids) != len(records) or not all(s in ids for s, _ in added):
        raise ValueError('rewritten database does not read back')
    return new_db, added


def write_big(game, new_db):
    game = Path(game)
    src = game / WC_BIG
    entries = big_entries(src)
    off, size, pos = entries[WC_DB]
    payload = chunkzip_encode(new_db)
    tmp = game / (WC_BIG + '.tmp')
    shutil.copyfile(src, tmp)  # a file of its own: the run folder's entry is a hard link to the dump
    with open(tmp, 'r+b') as f:
        f.seek(0, 2)
        end = f.tell()
        pad = (-end) % 0x800
        f.write(bytes(pad))
        new_off = end + pad
        f.write(payload)
        f.write(bytes((-(new_off + len(payload))) % 0x800))
        total = f.tell()
        f.seek(pos)
        f.write(struct.pack('>II', new_off, len(payload)))
        f.seek(4)
        f.write(struct.pack('<I', total & 0xffffffff))
    bh_src = game / 'data_worldcup.bh'
    bh = bytearray(bh_src.read_bytes())
    slots = [16 + 20 * i for i in range((len(bh) - 16) // 20)
             if struct.unpack_from('>II', bh, 16 + 20 * i) == (off, size)]
    if len(slots) != 1:
        tmp.unlink()
        raise ValueError(f'data_worldcup.bh: {len(slots)} entries for the database')
    struct.pack_into('>II', bh, slots[0], new_off, len(payload))
    bh_tmp = game / 'data_worldcup.bh.tmp'
    bh_tmp.write_bytes(bh)
    for final, t in ((src, tmp), (bh_src, bh_tmp)):
        final.unlink()  # never write through the hard link
        os.replace(t, final)


def main(game, assets):
    game = Path(game)
    stamp = game / STAMP
    built = game / '.update-built'
    if stamp.exists() and (not built.exists() or stamp.stat().st_mtime >= built.stat().st_mtime):
        return 0
    if os.stat(game / WC_BIG).st_nlink < 2 and stamp.exists():
        return 0
    new_db, added = build(game, assets)
    if added:
        write_big(game, new_db)
    stamp.write_text(''.join(f'{s}\t{n}\n' for s, n in added), encoding='utf-8')
    print(f'fifa14_wc_stadiums: {len(added)} stadiums added to the World Cup database')
    return 0


if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    try:
        sys.exit(main(*sys.argv[1:]))
    except (OSError, ValueError, KeyError, StopIteration, zlib.error) as e:
        print(f'fifa14_wc_stadiums: {e}', file=sys.stderr)
        sys.exit(2)
