#!/usr/bin/env python3
"""fifa14: build the folder the port runs from, with hard links (no extra disk space).

The dump keeps the console's encrypted SELF executables; the decrypted ELF copies sit in a
separate folder. This makes <out> = dump data + decrypted executables at their original paths:

    python fifa14_game_dir.py "E:/games ps4/CUSA00111" "E:/games ps4/CUSA00111/CUSA00111_dec" \
        "E:/games ps4/CUSA00111-port"

Decrypted files are matched to the dump by file name. A dump executable with no decrypted copy is
reported and left out (the loader would reject a SELF). Nothing in the dump is modified.
"""
import os
import shutil
import sys
from pathlib import Path

SELF_MAGIC = b'O\x15=\x1d'
ELF_MAGIC = b'\x7fELF'


def magic(path):
    with open(path, 'rb') as f:
        return f.read(4)


def place(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        dst.unlink()
    try:
        os.link(src, dst)
    except OSError:
        shutil.copy2(src, dst)  # another drive, or no hard-link support


def main(dump, dec, out):
    dump, dec, out = Path(dump), Path(dec), Path(out)
    decrypted = {}
    for p in dec.rglob('*'):
        if p.is_file() and magic(p) == ELF_MAGIC:
            decrypted[p.name.lower()] = p
    linked, replaced, missing = 0, [], []
    for p in dump.rglob('*'):
        if not p.is_file() or dec in p.parents:
            continue
        rel = p.relative_to(dump)
        if magic(p) == SELF_MAGIC:
            src = decrypted.get(p.name.lower())
            if src is None:
                missing.append(str(rel))
                continue
            place(src, out / rel)
            replaced.append(str(rel))
        else:
            place(p, out / rel)
            linked += 1
    print(f'{out}: {linked} data files linked, {len(replaced)} executables decrypted')
    for r in replaced:
        print(f'  ELF   {r}')
    for m in missing:
        print(f'  SKIP  {m} (no decrypted copy; still SELF)')


if __name__ == '__main__':
    if len(sys.argv) != 4:
        sys.exit(__doc__)
    main(*sys.argv[1:])
