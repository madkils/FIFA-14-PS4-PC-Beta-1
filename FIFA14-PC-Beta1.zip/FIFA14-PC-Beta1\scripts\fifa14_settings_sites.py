"""fifa14: the settings service behind the game's own settings screens (for the GRAPHICS category).

The settings screens (APT, data driven) ask everything from native functions registered under
their names (GetCategoriesIDs, GetSettingDescription, ...). Each one is a small wrapper that
forwards to one method of a global settings service object through its virtual table:

  lea rdi, [rip + native] ; call MakeNative ; lea rsi, "GetCategoriesIDs" ; ...   (registration)
  native: ... lea rax, [rip + service] ; mov rbx, [rax] ; mov rax, [rbx] ; mov r15, [rax + 0x58]

gpu/shim/fifa14_settings_ui.cpp replaces those methods in the service's virtual table with its own,
which add a category (resolution, antialiasing, window mode, FPS limit, quit) and forward the rest.
This prints, for BB_FIFA_SETTINGS_SITES, the ELF addresses of the service pointers and the table
offsets of the methods:

  python scripts/fifa14_settings_sites.py "<game dir>/eboot.bin"
  -> service=0x379e3d0,value_service=0x3af5060,categories=0x58,...

Nothing is printed when a native is missing or does not have the expected shape (exit code 2).
"""
import struct
import sys

# native name -> key printed (GetCurrent/SetCurrent/GetDefault use the second pointer)
NATIVES = {
    'GetChoiceListIDs': 'ids',
    'GetChoiceListDisplayStrings': 'strings',
    'GetSettingDescription': 'description',
    'GetCategoriesIDs': 'categories',
    'GetCategoryNames': 'names',
    'GetCategorySettingsIDs': 'settings',
    'GetSettingsImgAssetPath': 'image',
    'GetCurrentSettingValue': 'get',
    'SetCurrentSettingValue': 'set',
    'GetDefaultSettingValue': 'default',
}
VALUE_NATIVES = {'get', 'set', 'default'}


def load(path):
    f = open(path, 'rb').read()
    if f[:4] != b'\x7fELF':
        raise ValueError('not an ELF file')
    phoff, = struct.unpack_from('<Q', f, 0x20)
    phnum, = struct.unpack_from('<H', f, 0x38)
    segs = [struct.unpack_from('<IIQQQQQQ', f, phoff + 56 * i) for i in range(phnum)]
    loads = [s for s in segs if s[0] == 1]
    text = next(s for s in loads if s[1] & 1)
    return f, loads, text


def va_of(loads, off):
    for s in loads:
        if s[2] <= off < s[2] + s[5]:
            return s[3] + off - s[2]
    return None


def wrapper(code, base, fn):
    """(service pointer, table offset) of a native wrapper, or None."""
    i = fn - base
    if not 0 <= i < len(code) - 0x80:
        return None
    body = code[i:i + 0x80]
    k = body.find(b'\x48\x8d\x05')  # lea rax, [rip + service]
    if k < 0:
        return None
    service = fn + k + 7 + struct.unpack_from('<i', body, k + 3)[0]
    rest = body[k + 7:k + 7 + 16]
    # mov rbx|r13, [rax] ; mov rax, [rbx|r13] ; mov r15|r12|rax, [rax + imm8]
    loads_ = (b'\x48\x8b\x18\x48\x8b\x03', b'\x4c\x8b\x28\x49\x8b\x45\x00')
    for pre in loads_:
        if rest.startswith(pre):
            mov = rest[len(pre):len(pre) + 4]
            if mov[:2] in (b'\x4c\x8b', b'\x48\x8b') and mov[2] in (0x78, 0x60, 0x40):
                return service, mov[3]
    return None


def find(path):
    f, loads, text = load(path)
    code = f[text[2]:text[2] + text[5]]
    base = text[3]
    found = {}
    for name, key in NATIVES.items():
        pat = b'\0' + name.encode() + b'\0'
        targets = set()
        i = f.find(pat)
        while i >= 0:
            targets.add(va_of(loads, i + 1))
            i = f.find(pat, i + 1)
        results = set()
        i = code.find(b'\x48\x8d\x35')
        while i >= 0:
            disp, = struct.unpack_from('<i', code, i + 3)
            # lea rdi, [rip + native] ; call MakeNative ; (lea rcx, [rip + slot]) ; lea rsi, name
            if base + i + 7 + disp in targets:
                k = code.rfind(b'\x48\x8d\x3d', i - 0x20, i)
                if k >= 0 and code[k + 7] == 0xe8:
                    fn = base + k + 7 + struct.unpack_from('<i', code, k + 3)[0]
                    r = wrapper(code, base, fn)
                    if r:
                        results.add(r)
            i = code.find(b'\x48\x8d\x35', i + 1)
        if not results:
            raise ValueError(f'native {name} not found')
        found[key] = results
    # The settings service: the pointer the category natives use (other screens register natives
    # of the same names on other objects).
    service = next(iter(found['categories']))[0]
    # The value natives (Get/Set/GetDefault) use their own pointer (the same object in 1.0x): the
    # one GetCurrentSettingValue uses, which is registered only for the settings screens.
    if len({s for s, _ in found['get']}) != 1:
        raise ValueError('get: several services')
    value_service = next(iter(found['get']))[0]
    out = {}
    for key, results in found.items():
        want = value_service if key in VALUE_NATIVES else service
        mine = [off for s, off in results if s == want]
        if len(set(mine)) != 1:
            raise ValueError(f'{key}: not one method of the settings service')
        out[key] = mine[0]
    return service, value_service, out


def main():
    try:
        service, value_service, offsets = find(sys.argv[1])
    except (OSError, ValueError, StopIteration, IndexError) as e:
        print(f'fifa14_settings_sites: {e}', file=sys.stderr)
        sys.exit(2)
    print(f'service={service:#x},value_service={value_service:#x},' +
          ','.join(f'{k}={v:#x}' for k, v in sorted(offsets.items())))


if __name__ == '__main__':
    main()
