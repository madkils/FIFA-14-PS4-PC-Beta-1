"""fifa14: the game's own render size and MSAA, changed in the prepared image (not in the dump).

The renderer start-up fills a small structure with 1920, 1080, the aspect ratio and the options
SCREEN_WAITFORVSYNC and MULTISAMPLE (default 2); the display buffers are described by a second
structure with the same size. Both are literal writes in the executable, found here by their
instruction bytes (the same in the 1.00 and the update executables), so the game itself renders
at the requested size.

  python scripts/fifa14_render_patch.py out/fifa14/boot-linked.bin --size 2560x1440 [--msaa 4]

Every site must be found exactly once, otherwise nothing is written (exit code 2).
"""
import argparse
import struct
import sys
from pathlib import Path

W, H = struct.pack('<I', 1920), struct.pack('<I', 1080)
# (name, bytes before the width, bytes between width and height, kind)
SIZE_SITES = (
    # mov dword [rbp-0xe0], 1920 ; mov dword [rbp-0xdc], 1080      renderer start-up
    ('renderer', bytes.fromhex('c78520ffffff'), bytes.fromhex('c78524ffffff')),
    # mov dword [r12+0x20], 1920 ; mov dword [r12+0x24], 1080      display buffers
    ('display', bytes.fromhex('41c7442420'), bytes.fromhex('41c7442424')),
    # movabs rax, 1080<<32 | 1920                                  video output (buffer attribute)
    ('video out', bytes.fromhex('48b8'), b''),
)
# The MULTISAMPLE option's default, shortly after the renderer site (the lea of the name is
# rip-relative and differs per build; this part is fixed):
MSAA_CODE = bytes.fromhex('4889c7ba02000000b901000000')  # mov rdi,rax; mov edx,2; mov ecx,1
# The video memory heap ("SharedVideoMemoryGpuAddr", where the render targets live) is a fixed
# 1 GiB direct allocation: mov eax, 0x40000000 ; mov ebx, 3 (memory type). Sized for 1080p: at
# 3840x2160 the game stops with "Out of memory" in the render thread. It grows with the pixel count.
VIDEO_CODE = bytes.fromhex('b800000040') + bytes.fromhex('bb03000000')
BASE_VIDEO_MB = 1024
# Menus and cut-scenes at 30 FPS: the game's present call takes a vsync interval (1 = 60 FPS,
# 2 = 30 FPS) clamped to 0..3: xor eax,eax; test ecx,ecx; cmovns eax,ecx; mov ebx,3; cmp eax,3;
# cmovle ebx,eax. With the clamp at 1 the game never asks for 30.
INTERVAL_CODE = bytes.fromhex('31c085c90f49c1bb0300000083f8030f4ed8')


def video_mb(width, height, msaa=0):
    # The scene targets grow with the pixels and with the sample count (the game's default is 2).
    extra = (width * height / (1920 * 1080) * max(msaa or 2, 2) / 2 - 1) * 512
    return min(3584, BASE_VIDEO_MB + max(0, int(-(-extra // 64)) * 64))


def find_once(image, pattern, name):
    at = image.find(pattern)
    if at < 0 or image.find(pattern, at + 1) >= 0:
        raise ValueError(f'{name}: not found exactly once')
    return at


def patch(image, width, height, msaa, menus60=False):
    writes = []
    if menus60:
        at = find_once(image, INTERVAL_CODE, 'vsync interval clamp')
        writes.append((at + 8, b'\x01'))   # mov ebx, 1
        writes.append((at + 14, b'\x01'))  # cmp eax, 1
    if (width, height) == (1920, 1080) and not msaa:
        for at, data in writes:
            image[at:at + len(data)] = data
        return len(writes)
    for name, before, between in SIZE_SITES:
        at = find_once(image, before + W + between + H, name)
        writes.append((at + len(before), struct.pack('<I', width)))
        writes.append((at + len(before) + 4 + len(between), struct.pack('<I', height)))
    if msaa:
        name, before, between = SIZE_SITES[0]
        start = find_once(image, before + W + between + H, name)
        at = image.find(MSAA_CODE, start, start + 160)
        if at < 0:
            raise ValueError('multisample default: not found')
        writes.append((at + 4, struct.pack('<I', msaa)))
    vmb = video_mb(width, height, msaa)
    if vmb != BASE_VIDEO_MB:
        at = find_once(image, VIDEO_CODE, 'video memory heap')
        writes.append((at + 1, struct.pack('<I', vmb * 1024 * 1024)))
    for at, data in writes:
        image[at:at + len(data)] = data
    return len(writes)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('boot', type=Path)
    p.add_argument('--size', default='1920x1080')
    p.add_argument('--msaa', type=int, default=0, choices=(0, 1, 2, 4, 8))
    p.add_argument('--menus60', action='store_true', help='menus and cut-scenes at 60 FPS too')
    a = p.parse_args()
    width, height = (int(v) for v in a.size.lower().split('x'))
    if not (640 <= width <= 7680 and 360 <= height <= 4320) or width % 2 or height % 2:
        sys.exit('fifa14_render_patch: unsupported size')
    image = bytearray(a.boot.read_bytes())
    try:
        count = patch(image, width, height, a.msaa, a.menus60)
    except ValueError as e:
        print(f'fifa14_render_patch: {e}; nothing changed', file=sys.stderr)
        sys.exit(2)
    a.boot.write_bytes(image)
    vmb = video_mb(width, height, a.msaa)
    print(f'Render patch: game renders {width}x{height}' + (f', MSAA {a.msaa}x' if a.msaa else '') +
          (', menus at 60 FPS' if a.menus60 else '') +
          f', video heap {vmb} MiB ({count} writes)')
    # The extra video heap comes out of the direct memory pool: run-fifa14.sh raises BB_DMEM_MB.
    print(f'dmem_extra_mb={vmb - BASE_VIDEO_MB}')
